### Hexlet tests and linter status:
[![Actions Status](https://github.com/solumD/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/solumD/python-project-49/actions)
<a href="https://codeclimate.com/github/solumD/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/4c81aecbfa238286a6b2/maintainability" /></a>
